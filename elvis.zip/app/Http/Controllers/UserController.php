<?php
/**
 * Created by PhpStorm.
 * User: geeknat
 * Date: 11/26/18
 * Time: 8:27 AM
 */

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class UserController
{

    public function login(Request $request)
    {


        if ($request->has('username') && $request->has('password')) {

            $userName = $request->input('username');
            $password = $request->input('password');
            //$password = Hash::make($password);

            $user = DB::table('users')
                ->select('id', 'first_name', 'last_name', 'username', 'email')
                ->where('username', $userName)
                ->where('password', $password)
                ->get();

            if ($user->count() == 0) {
                return response()->json(array('success' => 0, 'message' => 'Failed to log in'), 200);
            }

            return response()->json(array('success' => 1, 'message' => $user[0]), 200);

        }

        return response()->json(array('success' => 0, 'message' => 'Invalid request'), 200);

    }


}